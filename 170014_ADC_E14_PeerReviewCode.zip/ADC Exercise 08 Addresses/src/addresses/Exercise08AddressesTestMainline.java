package addresses;

/*******
 * <p> Title: IndiaAddress Class </p>
 * 
 * <p> Description: A demonstration of a hierarchy of classes inheriting common data </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-20 </p>
 * 
 * @author Lynn Robert Carter
 * @author Shivi Mittal
 * 
 * @version 1.00	2018-09-19 A set of classes that shows inheritence 
 * 
 */

public class Exercise08AddressesTestMainline {

	public static void main(String[] args) {
		
	
		// Demonstrate that the Qatar Address holds the data and prints it properly
				QatarBusinessAddress CMUQatarAddress = new QatarBusinessAddress (
						"Office of Undergraduate Admissions",
						"Carnegie Mellon University",
						"c/o Qatar Foundation",
						"P.O. Box 24866",
						"Doha",
						"Qatar");
		
		
		
		// Demonstrate that the India Address holds the data and prints it properly
		FriendAdd friAdd = new FriendAdd (
				"Uma",
				"4/17-A, Sri Krishan Nagar",
				"Tirupati",
				"Andhra Pradesh",
				"517502",
				"India");
		
		// Demonstrate that the India Address holds the data and prints it properly
		FriendAdd2 friAdd2 = new FriendAdd2 (
				"Jawahar",
				"13-152/1, LB Nagar",
				"Tirupati",
				"Andhra Pradesh",
				"517502",
				"India");
		// Demonstrate that the India Address holds the data and prints it properly
		FriendAdd3 friAdd3 = new FriendAdd3 (
				"Keshav",
				"#70, Maharaja City Morinda Road",
				"Rupnagar",
				"Punjab",
				"140001",
				"India");
		// Demonstrate that the India Address holds the data and prints it properly
		FriendAdd4 friAdd4 = new FriendAdd4 (
				"Ujjwal",
				"J.C. Mallick road, Hirapur",
				"Dhanbad",
				"Jharkhand",
				"826001",
				"India");
		
		// The following display the information stored above in a format appropriate for mailing
		System.out.println(friAdd);
		System.out.println("------");
		System.out.println(friAdd2);
		System.out.println("------");
		System.out.println(CMUQatarAddress);
		System.out.println("------");
		System.out.println(friAdd3);
		System.out.println("------");
		System.out.println(friAdd4);
		System.out.println("------");
	}
}