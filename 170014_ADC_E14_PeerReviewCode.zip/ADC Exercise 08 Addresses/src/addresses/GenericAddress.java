package addresses;

/*******
 * <p> Title: GenericAddress Class </p>
 * 
 * <p> Description: A demonstration of a hierarchy of classes inheriting common data </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-20 </p>
 * 
 * @author Lynn Robert Carter
 * @author Shivi Mittal
 * 
 * @version 1.00	2018-09-19 A set of classes that shows inheritence 
 * 
 */


public class GenericAddress {
	
	protected String city;
	protected String country;

	/**********
	 * Default constructor
	 * 
	 * @return a generic address with all field set to the empty string
	 */
	public GenericAddress() {
		
		city = "";
		country = "";
	}
	
	/**********
	 * Fully-specified constructor
	 * 
	 * @param n - Name
	 * @param a - Address
	 * @param c - City
	 * @param cn - Country Name
	 * 
	 * @return a fully specified generic address
	 */
	public GenericAddress(String c, String cn){
		
		city = c;
		country = cn;
	}
	
	/**********
	 * Overridden toString method for this class showing the values of all of the attributes
	 * 
	 * @return a string formatted to show the address in a generic form
	 */
	public String toString() {
		return city + "\n" + country;
	}
}
