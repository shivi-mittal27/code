package addresses;

/*******
 * <p> Title: QatarBusinessAddress Class </p>
 * 
 * <p> Description: A demonstration of a hierarchy of classes inheriting common data </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-20 </p>
 * 
 *@author Shivi Mittal
 * 
 * @version 1.00	2018-09-19 A set of classes that shows inheritence 
 * 
 */

public class FriendAdd3 extends IndiaAddress {
	
	protected String state;

	/**********
	 * Default constructor
	 * 
	 * @return a generic address with all field set to the empty string
	 */
	public FriendAdd3() {
		super();
	}

	
	/**********
	 * Fully-specified constructor
	 * 
	 * 
	 * @param s - state
	 * 
	 * @return a fully specified United States address
	 */
	public FriendAdd3(String n, String a, String c, String s, String z, String cn) {
		super();
		name =n;
		address =a;
		city = c;
		state = s;
		zipcode = z;
		country = cn;
	}
	
	/**********
	 * Overridden toString method for this class showing the values of all of the attributes
	 * 
	 * @return a string formatted to show the address in format appropriate for the United States
	 */
	
	public String toString() {
		return name + "\n" + address  + "\n" + city + ", " + state + " " + zipcode + "\n" + country;
	}
}